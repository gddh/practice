from django.urls import path

from .views import shorten, recent, top, count


urlpatterns = [
    path('shorten/', shorten),
    path('recent/', recent),
    path('top/', top),
    path('count/', count),
]
