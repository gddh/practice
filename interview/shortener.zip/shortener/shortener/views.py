

def shorten(request):
    """
    An endpoint that receives a URL and returns a new shortened URL
    """
    pass


def recent(request):
    """
    An endpoint to retrieve the last 100 shortened URLs
    """
    pass


def top(request):
    """
    An endpoint to retrieve the top 10 most popular shortened domains in the past month
    """


def count(request):
    """
    An endpoint to retrieve the number of times a shortened URL has been visited.
    """
    pass
